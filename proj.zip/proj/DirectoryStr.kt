lab-04
├── public
│   ├── style.css
│   ├── data
│   │   ├── patient-data.csv
│   │   └── weather-data.json
│   └── images
├── routes
│   └── index.js
├── uploads
└── views
    ├── layouts
    │   └── main.handlebars
    ├── weather.handlebars
    ├── patient.handlebars
    ├── form.handlebars
    ├── home.handlebars
    └── images.handlebars
